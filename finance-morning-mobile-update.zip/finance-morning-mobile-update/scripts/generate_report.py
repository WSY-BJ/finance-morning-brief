#!/usr/bin/env python3
"""Build the daily public-market brief without private account data."""
from __future__ import annotations

import csv
from concurrent.futures import ThreadPoolExecutor
import io
import json
import time
import urllib.parse
import urllib.request
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parents[1]
TZ = ZoneInfo("Asia/Shanghai")
UA = "finance-morning-brief/1.0 (+https://github.com/WSY-BJ/finance-morning-brief)"
ASSETS = [
    ("SPY", "标普500 ETF", "spy.us"),
    ("QQQ", "纳指100 ETF", "qqq.us"),
    ("FXI", "中国大盘股 ETF", "fxi.us"),
    ("EEM", "新兴市场 ETF", "eem.us"),
    ("TLT", "长期美债 ETF", "tlt.us"),
    ("GLD", "黄金 ETF", "gld.us"),
    ("USO", "原油 ETF", "uso.us"),
]

ASSET_INFO = {
    "SPY": {
        "name": "标普500 ETF",
        "plain": "可以把它理解成“一篮子美国大型公司”，覆盖苹果、微软等龙头企业。",
        "watch": "常用来观察美国大盘股的整体温度。",
    },
    "QQQ": {
        "name": "纳指100 ETF",
        "plain": "主要装着美国大型科技与成长公司，科技股权重较高。",
        "watch": "对利率变化和科技公司盈利预期通常更敏感。",
    },
    "FXI": {
        "name": "中国大盘股 ETF",
        "plain": "持有在香港上市的中国大型公司，金融与互联网企业较多。",
        "watch": "可辅助观察海外资金眼中的中国大盘股，但不等于沪深指数。",
    },
    "EEM": {
        "name": "新兴市场 ETF",
        "plain": "集合中国、印度、台湾地区、巴西等新兴市场的股票。",
        "watch": "常受美元、全球资金流和各地经济增长预期影响。",
    },
    "TLT": {
        "name": "长期美债 ETF",
        "plain": "主要持有期限很长的美国国债，价格对长期利率变化很敏感。",
        "watch": "利率下降时通常受益，利率上升时通常承压，但并非每次都如此。",
    },
    "GLD": {
        "name": "黄金 ETF",
        "plain": "用基金份额跟踪黄金价格，省去直接保管实物黄金。",
        "watch": "常结合美元、实际利率、避险需求一起观察。",
    },
    "USO": {
        "name": "原油 ETF",
        "plain": "主要通过原油期货合约反映油价变化，并不是直接持有一桶桶原油。",
        "watch": "除供需外还受期货换月成本影响，长期表现可能偏离现货油价。",
    },
}


def get_text(url: str, timeout: int = 20) -> str:
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "text/csv,application/json;q=0.9,*/*;q=0.8"})
    with urllib.request.urlopen(req, timeout=timeout) as res:
        return res.read().decode("utf-8-sig")


def stooq_quote(ticker: str, stooq_symbol: str) -> dict:
    end = datetime.now(TZ).date()
    start = end - timedelta(days=20)
    url = "https://stooq.com/q/d/l/?" + urllib.parse.urlencode({"s": stooq_symbol, "d1": start.strftime("%Y%m%d"), "d2": end.strftime("%Y%m%d"), "i": "d"})
    rows = [r for r in csv.DictReader(io.StringIO(get_text(url))) if r.get("Close") not in (None, "", "N/D")]
    if len(rows) < 2:
        raise RuntimeError(f"{ticker}: Stooq returned fewer than two rows")
    prev, latest = rows[-2], rows[-1]
    close, previous = float(latest["Close"]), float(prev["Close"])
    return {"ticker": ticker, "date": latest["Date"], "close": close, "changePct": (close / previous - 1) * 100,
            "high": float(latest["High"]), "low": float(latest["Low"]), "provider": "Stooq",
            "source": f"https://stooq.com/q/?s={stooq_symbol}"}


def yahoo_quote(ticker: str) -> dict:
    url = f"https://query1.finance.yahoo.com/v8/finance/chart/{urllib.parse.quote(ticker)}?range=10d&interval=1d"
    result = json.loads(get_text(url))["chart"]["result"][0]
    timestamps, quote = result["timestamp"], result["indicators"]["quote"][0]
    rows = []
    for i, ts in enumerate(timestamps):
        close = quote["close"][i]
        if close is not None:
            rows.append((ts, float(close), quote["high"][i], quote["low"][i]))
    if len(rows) < 2:
        raise RuntimeError(f"{ticker}: Yahoo returned fewer than two rows")
    prev, latest = rows[-2], rows[-1]
    return {"ticker": ticker, "date": datetime.fromtimestamp(latest[0], TZ).date().isoformat(), "close": latest[1],
            "changePct": (latest[1] / prev[1] - 1) * 100, "high": float(latest[2]), "low": float(latest[3]),
            "provider": "Yahoo Finance", "source": f"https://finance.yahoo.com/quote/{ticker}/"}


def get_quote(ticker: str, stooq_symbol: str) -> dict:
    errors = []
    for fn, args in ((stooq_quote, (ticker, stooq_symbol)), (yahoo_quote, (ticker,))):
        try:
            return fn(*args)
        except Exception as exc:
            errors.append(type(exc).__name__)
            time.sleep(0.5)
    raise RuntimeError(f"{ticker}: all public quote sources failed ({', '.join(errors)})")


def fmt_pct(value: float) -> str:
    return f"{value:+.2f}%".replace("-", "−")


def build_report(quotes: list[dict]) -> dict:
    now = datetime.now(TZ)
    today = now.date().isoformat()
    by_ticker = {q["ticker"]: q for q in quotes}
    best = max(quotes, key=lambda q: q["changePct"])
    worst = min(quotes, key=lambda q: q["changePct"])
    latest_market_date = max(q["date"] for q in quotes)
    best_name = ASSET_INFO[best["ticker"]]["name"]
    worst_name = ASSET_INFO[worst["ticker"]]["name"]
    title = f"{best_name}领涨，{worst_name}相对承压"
    summary = f"最近交易日{best_name}变动{fmt_pct(best['changePct'])}，表现相对最强；{worst_name}变动{fmt_pct(worst['changePct'])}。"
    names = {ticker: name for ticker, name, _ in ASSETS}
    metrics = [{
        "label": f"{q['ticker']} · {names[q['ticker']]}",
        "value": f"{q['close']:.2f}",
        "changePct": round(q["changePct"], 4),
        "direction": "up" if q["changePct"] > 0 else "down" if q["changePct"] < 0 else "flat",
        "note": f"较前一交易日 {fmt_pct(q['changePct'])} · 当日区间 {q['low']:.2f}–{q['high']:.2f}",
        "plain": ASSET_INFO[q["ticker"]]["plain"],
        "focus": "相对最强" if q["ticker"] == best["ticker"] else "相对最弱" if q["ticker"] == worst["ticker"] else "",
    } for q in quotes]
    glossary = [{"symbol": ticker, **ASSET_INFO[ticker]} for ticker, _, _ in ASSETS]
    risk_on = by_ticker["QQQ"]["changePct"] - by_ticker["TLT"]["changePct"]
    style_text = "成长资产相对占优" if risk_on > 0 else "防御资产相对占优"
    return {
        "edition": f"自动晨报 · {today}", "date": f"生成于北京时间 {now:%Y-%m-%d %H:%M}；行情截至 {latest_market_date}",
        "reportDate": today, "updatedAt": now.isoformat(timespec="seconds"), "status": "published", "title": title,
        "subtitle": "全球财经 · 新手友好 · 金融工程每日一课",
        "intro": "先用通俗解释认识这些市场工具，再看价格变化。本期由独立 GitHub Actions 流水线采集公开行情生成，不连接交易账户，不包含个人持仓。",
        "notification": {"title": f"{today} 财经晨报", "summary": summary},
        "pages": [
            {"id":"overview","eyebrow":"01 · 开篇","title":"晨间速览","lead":"先看结论，再理解这些数字代表什么；单日变化不等于趋势。","blocks":[
                {"type":"notice","tone":"neutral","title":"数据说明","text":"价格来自公开延迟行情；若核心数据采集或在线校验失败，本期不会发布，也不会发送微信通知。"},
                {"type":"bullets","title":"今日三条","items":[summary, f"风格：科技成长股篮子（QQQ）相对长期美债篮子（TLT）的当日差值为 {risk_on:+.2f} 个百分点，{style_text}。", "方法：ETF 是可交易的一篮子资产，不等于指数点位、现货价格或期货结算价，比较前需统一口径。"]},
                {"type":"chain","title":"研究顺序","items":["价格变化","宏观证据","盈利与现金流","估值","风险情景"]}]},
            {"id":"markets","eyebrow":"02 · 市场","title":"市场工具与价格快照","lead":"这些代码多数代表 ETF（可交易的一篮子资产），不是指数本身。价格单位为美元，涨跌幅相对上一交易日收盘。","blocks":[
                {"type":"metricGrid","title":"最近交易日","items":metrics},
                {"type":"glossary","title":"第一次看？逐个认识","items":glossary},
                {"type":"notice","tone":"focus","title":"读数方法","text":"红色“上涨”和绿色“下跌”只描述上一交易日的价格方向，不代表应该买入或卖出；先看变化，再寻找利率、盈利、政策或供需证据。"},
                {"type":"bullets","title":"观察要点","items":[f"美国股票：SPY {fmt_pct(by_ticker['SPY']['changePct'])}，QQQ {fmt_pct(by_ticker['QQQ']['changePct'])}。", f"债券与商品：TLT {fmt_pct(by_ticker['TLT']['changePct'])}，GLD {fmt_pct(by_ticker['GLD']['changePct'])}，USO {fmt_pct(by_ticker['USO']['changePct'])}。", f"中国与新兴市场：FXI {fmt_pct(by_ticker['FXI']['changePct'])}，EEM {fmt_pct(by_ticker['EEM']['changePct'])}。"]}]},
            {"id":"radar","eyebrow":"03 · 研究","title":"跨资产观察","lead":"研究框架面向公开市场，不针对任何个人账户。","blocks":[
                {"type":"research","title":"科技股与长期国债","thesis":"比较 QQQ 与 TLT：前者偏科技成长股，后者是长期美国国债。两者都对利率变化较敏感，但反应方向不一定相同。","verify":"继续看国债收益率、企业盈利预期、上涨股票数量和成交量。","risk":"一天的涨跌可能只是噪声，不能单独证明“利率导致了股价变化”。"},
                {"type":"research","title":"黄金与原油","thesis":"黄金常与避险、美元和实际利率有关；原油更直接受全球供需、库存和地缘事件影响。","verify":"继续看美元、扣除通胀后的实际收益率、原油库存与资金流。","risk":"ETF 有管理费和跟踪误差，原油 ETF 还会受期货换月成本影响。"},
                {"type":"research","title":"中国与新兴市场","thesis":"FXI 偏中国大型企业，EEM 覆盖多个新兴经济体；比较两者可粗略观察区域风险偏好差异。","verify":"继续看汇率、企业盈利预期、政策变化与国际资金流。","risk":"ETF 的持仓构成与沪深、恒生等本地指数并不完全相同。"}]},
            {"id":"lesson","eyebrow":"04 · 每日一课","title":"相关不等于因果","lead":"两类资产同向或反向变化，只是研究起点。","blocks":[
                {"type":"formula","title":"相关系数","expression":"ρ(X,Y) = Cov(X,Y) ÷ (σX · σY)","note":"相关系数描述线性共同变化，不证明 X 导致 Y；样本区间改变，结果也可能改变。"},
                {"type":"quiz","title":"30秒自测","question":"黄金上涨且美元下跌，能否仅凭一天数据断定美元下跌导致黄金上涨？","answer":"不能。还需控制利率、风险偏好、事件冲击等变量，并使用更长样本验证。"}]},
            {"id":"watch","eyebrow":"05 · 清单","title":"下一次更新看什么","lead":"固定网址提供最新晨报，历史入口用于推送失败时回看。","blocks":[
                {"type":"bullets","title":"公开观察清单","items":["主要央行政策与利率预期。","通胀、就业、消费数据是否偏离预期。","指数上涨是否集中于少数权重股。","黄金、原油变化是否得到利率和供需数据支持。"]},
                {"type":"notice","tone":"neutral","title":"隐私边界","text":"本站没有登录、支付、交易或统计功能；仓库不含账户信息、私人持仓、Cookie、访问令牌或 API 密钥。"}]}
        ],
        "sources": [{"title": f"{q['ticker']} · {q['provider']}", "url": q["source"], "asOf": q["date"]} for q in quotes]
    }


def write_outputs(report: dict) -> None:
    archive_dir = ROOT / "archive"
    archive_dir.mkdir(exist_ok=True)
    date = report["reportDate"]
    encoded = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    (ROOT / "report.json").write_text(encoded, encoding="utf-8")
    (archive_dir / f"{date}.json").write_text(encoded, encoding="utf-8")
    index_path = archive_dir / "index.json"
    try:
        index = json.loads(index_path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError):
        index = {"items": []}
    entry = {"date": date, "title": report["title"], "summary": report["notification"]["summary"], "url": f"?date={date}#overview"}
    items = [entry] + [x for x in index.get("items", []) if x.get("date") != date]
    items = sorted(items, key=lambda x: x.get("date", ""), reverse=True)[:120]
    index_path.write_text(json.dumps({"updatedAt": report["updatedAt"], "items": items}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main() -> None:
    with ThreadPoolExecutor(max_workers=3) as pool:
        futures = {ticker: pool.submit(get_quote, ticker, stooq_symbol) for ticker, _, stooq_symbol in ASSETS}
        quotes = [futures[ticker].result() for ticker, _, _ in ASSETS]
    required = {"SPY", "QQQ", "GLD", "USO"}
    if not required.issubset({q["ticker"] for q in quotes}):
        raise SystemExit("Core public-market data is incomplete; refusing to publish")
    report = build_report(quotes)
    write_outputs(report)
    print(f"Generated {report['reportDate']} from {len(quotes)} public instruments")


if __name__ == "__main__":
    main()
